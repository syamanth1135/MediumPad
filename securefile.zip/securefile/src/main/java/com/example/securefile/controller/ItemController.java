package com.example.securefile.controller;

import com.example.securefile.entity.Item;
import com.example.securefile.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ItemController {

    @Autowired
    private ItemRepository itemRepository;

    // Store text
    @PostMapping("/store-text")
    public ResponseEntity<String> storeText(@RequestBody ItemRequest request) {
        try {
            Item item = new Item();
            item.setTitle(request.getTitle());
            item.setType("text");
            item.setContent(request.getContent());
            item.setPinHash(hashPin(request.getPin()));

            itemRepository.save(item);
            return ResponseEntity.ok("Text stored successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error storing text.");
        }
    }

    // Store file
    @PostMapping("/store-file")
    public ResponseEntity<String> storeFile(@RequestParam("title") String title,
                                            @RequestParam("pin") String pin,
                                            @RequestParam("file") MultipartFile file) {
        try {
            Item item = new Item();
            item.setTitle(title);
            item.setType("file");
            item.setFileData(file.getBytes());
            item.setFileName(StringUtils.cleanPath(file.getOriginalFilename()));
            item.setContentType(file.getContentType());
            item.setPinHash(hashPin(pin));

            itemRepository.save(item);
            return ResponseEntity.ok("File stored successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error storing file.");
        }
    }

    // Retrieve item by ID and PIN
    @PostMapping("/get-item")
    public ResponseEntity<?> getItem(@RequestParam Long id, @RequestParam String pin) {
        Optional<Item> optionalItem = itemRepository.findById(id);
        if (optionalItem.isEmpty()) return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Item not found");

        Item item = optionalItem.get();
        if (!item.getPinHash().equals(hashPin(pin))) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid PIN");

        if ("file".equals(item.getType())) {
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + item.getFileName() + "\"")
                    .contentType(MediaType.parseMediaType(item.getContentType()))
                    .body(item.getFileData());
        } else {
            return ResponseEntity.ok(item.getContent());
        }
    }

    // PIN hashing method
    private String hashPin(String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(pin.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            throw new RuntimeException("PIN hashing failed", e);
        }
    }

    // DTO class
    public static class ItemRequest {
        private String title;
        private String content;
        private String pin;

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }

        public String getContent() { return content; }
        public void setContent(String content) { this.content = content; }

        public String getPin() { return pin; }
        public void setPin(String pin) { this.pin = pin; }
    }
}
