// Configuration
const API_BASE = 'http://localhost:8081/api';
let currentItems = [];
let selectedItem = null;
let currentTextContent = null; // Store current text content for operations

// Navigation
function showPage(pageId) {
  document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });
  document.getElementById(pageId + 'Page').classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  event.target.classList.add('active');
  document.getElementById('alertContainer').innerHTML = '';
  if (pageId !== 'storage') {
    document.getElementById('successDisplay').style.display = 'none';
  }
}

// Show alert messages
function showAlert(message, type = 'error') {
  const alertContainer = document.getElementById('alertContainer');
  const alertDiv = document.createElement('div');
  alertDiv.className = `alert alert-${type}`;
  alertDiv.textContent = message;
  alertContainer.innerHTML = '';
  alertContainer.appendChild(alertDiv);
  setTimeout(() => {
    if (alertDiv.parentNode) {
      alertDiv.remove();
    }
  }, 5000);
}

// Show loading spinner
function showLoading(elementId, show) {
  const loader = document.getElementById(elementId);
  if (loader) {
    loader.style.display = show ? 'inline-block' : 'none';
  }
}

// File input change handler
document.getElementById('file').addEventListener('change', function(e) {
  const file = e.target.files[0];
  const fileInfo = document.getElementById('fileInfo');
  if (file) {
    const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
    fileInfo.innerHTML = `
      <strong>Selected file:</strong> ${file.name}<br>
      <strong>Size:</strong> ${sizeInMB} MB<br>
      <strong>Type:</strong> ${file.type || 'Unknown'}
    `;
    fileInfo.style.display = 'block';
  } else {
    fileInfo.style.display = 'none';
  }
});

async function storeItem() {
  const title = document.getElementById('title').value.trim();
  const pin = document.getElementById('pin').value.trim();
  const text = document.getElementById('text').value.trim();
  const file = document.getElementById('file').files[0];
  
  if (!title || !pin) {
    showAlert("Please enter both title and PIN.");
    return;
  }
  if (pin.length < 4) {
    showAlert("PIN must be at least 4 characters long.");
    return;
  }
  if (!text && !file) {
    showAlert("Please enter either text content or select a file to upload.");
    return;
  }
  if (text && file) {
    showAlert("Please choose either text content OR file upload, not both.");
    return;
  }
  
  showLoading('storeLoading', true);
  
  try {
    // First, check if PIN is already in use
    const isPinUnique = await checkPinUniqueness(pin);
    if (!isPinUnique) {
      showAlert("This PIN is already in use. Please choose a different PIN.");
      showLoading('storeLoading', false);
      return;
    }
    
    let response;
    if (file) {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('title', title);
      formData.append('pin', pin);
      
      console.log('Uploading file:', {
        name: file.name,
        size: file.size,
        type: file.type
      });
      
      response = await fetch(`${API_BASE}/store-file`, { 
        method: 'POST', 
        body: formData 
      });
    } else {
      response = await fetch(`${API_BASE}/store-text`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          title: title, 
          pin: pin, 
          content: text 
        })
      });
    }
    
    const responseText = await response.text();
    console.log('Store response:', {
      status: response.status,
      headers: Object.fromEntries(response.headers.entries()),
      body: responseText
    });
    
    if (response.ok) {
      const idMatch = responseText.match(/ID:\s*(\d+)/);
      const itemId = idMatch ? idMatch[1] : 'Unknown';
      document.getElementById('displayedPin').textContent = pin;
      document.getElementById('displayedId').textContent = itemId;
      document.getElementById('successDisplay').style.display = 'block';
      showAlert(responseText, 'success');
      
      // Clear form
      document.getElementById('title').value = '';
      document.getElementById('pin').value = '';
      document.getElementById('text').value = '';
      document.getElementById('file').value = '';
      document.getElementById('fileInfo').style.display = 'none';
    } else {
      // Check if it's a PIN conflict error from backend
      if (response.status === 409 || responseText.toLowerCase().includes('pin') && responseText.toLowerCase().includes('exist')) {
        showAlert("This PIN is already in use. Please choose a different PIN.");
      } else {
        showAlert("Error storing item: " + responseText);
      }
    }
  } catch (err) {
    console.error('Store error:', err);
    showAlert(`Network error occurred while storing item: ${err.message}`);
  } finally {
    showLoading('storeLoading', false);
  }
}

// Function to check if PIN is already in use
async function checkPinUniqueness(pin) {
  try {
    // Try to access any item with this PIN by testing a range of IDs
    for (let id = 1; id <= 100; id++) {
      const formData = new FormData();
      formData.append('id', id.toString());
      formData.append('pin', pin);
      
      const response = await fetch(`${API_BASE}/get-item`, {
        method: 'POST',
        body: formData
      });
      
      // If we find any item with this PIN, it's not unique
      if (response.ok) {
        return false;
      }
      
      // If we get a 403 (forbidden), the PIN exists but doesn't match this ID
      if (response.status === 403) {
        return false;
      }
      
      // 404 means this ID doesn't exist, continue checking
    }
    
    // If we didn't find any items with this PIN, it's unique
    return true;
  } catch (err) {
    console.error('Error checking PIN uniqueness:', err);
    // If there's an error checking, allow the storage attempt
    // The backend should handle the final validation
    return true;
  }
}

async function searchUserItems() {
  const pin = document.getElementById('accessPin').value.trim();
  if (!pin) {
    showAlert("Please enter your PIN.");
    return;
  }
  
  showLoading('searchLoading', true);
  try {
    let foundItems = [];
    let searchRange = 1000;
    let checkedCount = 0;
    let consecutiveNotFound = 0;
    const maxConsecutiveNotFound = 50;
    
    showAlert("Searching for your items... This may take a moment.", 'success');
    
    for (let id = 1; id <= searchRange; id++) {
      try {
        const formData = new FormData();
        formData.append('id', id.toString());
        formData.append('pin', pin);
        
        const response = await fetch(`${API_BASE}/get-item`, {
          method: 'POST',
          body: formData
        });
        
        checkedCount++;
        if (checkedCount % 50 === 0) {
          showAlert(`Searched ${checkedCount} items... Found ${foundItems.length} so far.`, 'success');
        }
        
        if (response.ok) {
          consecutiveNotFound = 0;
          const contentType = response.headers.get('content-type');
          const contentDisposition = response.headers.get('content-disposition');
          
          let itemType = 'text';
          let title = `Item #${id}`;
          
          // Better file detection
          if (contentDisposition && contentDisposition.includes('filename')) {
            const matches = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(contentDisposition);
            if (matches && matches[1]) {
              title = matches[1].replace(/['"]/g, '');
              itemType = 'file';
            }
          } else if (contentType && !contentType.includes('text/plain') && !contentType.includes('application/json')) {
            itemType = 'file';
            title = `File #${id}`;
          } else {
            try {
              const content = await response.text();
              const preview = content.length > 50 ? content.substring(0, 50) + '...' : content;
              title = `Text: ${preview}`;
            } catch (e) {
              title = `Text Item #${id}`;
            }
          }
          
          foundItems.push({
            id: id,
            type: itemType,
            title: title,
            contentType: contentType,
            contentDisposition: contentDisposition
          });
        } else if (response.status === 404) {
          consecutiveNotFound++;
          if (foundItems.length === 0 && consecutiveNotFound > 20) {
            showAlert("No items found. Please check your PIN and try again.");
            showLoading('searchLoading', false);
            return;
          }
          if (consecutiveNotFound >= maxConsecutiveNotFound) {
            console.log(`Stopping search after ${maxConsecutiveNotFound} consecutive items not found`);
            break;
          }
        } else {
          consecutiveNotFound = 0;
        }
      } catch (err) {
        consecutiveNotFound++;
        if (consecutiveNotFound >= maxConsecutiveNotFound) {
          console.log('Stopping search due to network errors');
          break;
        }
        continue;
      }
    }
    
    if (foundItems.length === 0) {
      showAlert(`No items found with this PIN. Searched ${checkedCount} possible items.`);
      document.getElementById('itemsList').style.display = 'none';
    } else {
      displayFoundItems(foundItems);
      showAlert(`Found ${foundItems.length} items!`, 'success');
    }
  } catch (err) {
    console.error('Search error:', err);
    showAlert(`Search error: ${err.message}`);
  } finally {
    showLoading('searchLoading', false);
  }
}

function displayFoundItems(items) {
  const itemsContainer = document.getElementById('itemsContainer');
  const itemsList = document.getElementById('itemsList');
  const itemsListTitle = document.getElementById('itemsListTitle');
  
  itemsListTitle.textContent = `Found ${items.length} Items:`;
  itemsContainer.innerHTML = items.map(item => `
    <div class="item-card" onclick="selectItem(${item.id})">
      <div class="item-title">${escapeHtml(item.title)}</div>
      <div class="item-meta">
        ID: ${item.id} | Type: ${item.type}
        ${item.contentType ? ' | MIME: ' + item.contentType : ''}
      </div>
    </div>
  `).join('');
  
  itemsList.style.display = 'block';
  document.getElementById('selectedItemContent').style.display = 'none';
}

async function selectItem(itemId) {
  const pin = document.getElementById('accessPin').value.trim();
  try {
    const formData = new FormData();
    formData.append('id', itemId);
    formData.append('pin', pin);
    
    const response = await fetch(`${API_BASE}/get-item`, {
      method: 'POST',
      body: formData
    });
    
    if (response.ok) {
      await displayItemContent(response, itemId);
    } else {
      const errorText = await response.text();
      showAlert(`Error loading item: ${errorText}`);
    }
  } catch (err) {
    console.error('Select item error:', err);
    showAlert(`Error loading item: ${err.message}`);
  }
}

async function displayItemContent(response, itemId) {
  const contentType = response.headers.get('content-type');
  const contentDisposition = response.headers.get('content-disposition');
  const contentDisplay = document.getElementById('contentDisplay');
  const downloadBtn = document.getElementById('downloadBtn');
  const downloadTextBtn = document.getElementById('downloadTextBtn');
  const copyBtn = document.getElementById('copyBtn');
  const fileDetails = document.getElementById('fileDetails');
  
  console.log('Displaying content:', {
    contentType,
    contentDisposition,
    itemId
  });
  
  // Reset button states
  downloadBtn.style.display = 'none';
  downloadTextBtn.style.display = 'none';
  copyBtn.style.display = 'none';
  
  // Check if it's a text response
  if (contentType && (contentType.includes('text/plain') || contentType.includes('application/json'))) {
    try {
      const content = await response.text();
      currentTextContent = content; // Store for operations
      
      // Create enhanced text preview
      const wordCount = content.split(/\s+/).filter(word => word.length > 0).length;
      const charCount = content.length;
      const lineCount = content.split('\n').length;
      
      contentDisplay.innerHTML = `
        <div class="text-preview-container">
          <div class="text-preview-header">
            <div class="text-preview-title">
              📝 Text Content
            </div>
            <div class="text-stats">
              ${lineCount} lines • ${wordCount} words • ${charCount} characters
            </div>
          </div>
          <div class="text-content-preview">${escapeHtml(content)}</div>
        </div>
      `;
      
      // Show text-specific buttons
      downloadTextBtn.style.display = 'inline-block';
      copyBtn.style.display = 'inline-block';
      
      fileDetails.innerHTML = `
        <strong>Type:</strong> Text content<br>
        <strong>Content-Type:</strong> ${contentType}<br>
        <strong>Statistics:</strong> ${lineCount} lines, ${wordCount} words, ${charCount} characters
      `;
    } catch (err) {
      console.error('Error reading text content:', err);
      showAlert(`Error reading text content: ${err.message}`);
      return;
    }
  } else {
    // Handle as file - read blob BEFORE storing response info
    try {
      const blob = await response.blob();
      console.log('File blob created:', {
        size: blob.size,
        type: blob.type
      });
      
      // Store file info without cloning the response
      let filename = 'downloaded_file';
      if (contentDisposition) {
        const matches = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(contentDisposition);
        if (matches && matches[1]) {
          filename = matches[1].replace(/['"]/g, '');
        }
      }
      
      // Store the blob and metadata for download
      selectedItem = { 
        blob, 
        filename,
        contentType: contentType || blob.type,
        contentDisposition,
        itemId 
      };
      
      const fileSizeMB = (blob.size / (1024 * 1024)).toFixed(2);
      
      // Generate preview based on file type
      const previewHtml = await generateFilePreview(blob, filename, selectedItem.contentType);
      
      contentDisplay.innerHTML = `
        <div style="margin-bottom: 20px;">
          <h4 style="margin-bottom: 15px; color: #333;">📄 ${escapeHtml(filename)}</h4>
          <div style="margin-bottom: 15px; padding: 10px; background: #f8f9fa; border-radius: 5px; font-size: 14px;">
            <strong>Size:</strong> ${fileSizeMB} MB | 
            <strong>Type:</strong> ${selectedItem.contentType || 'Unknown'}
          </div>
        </div>
        ${previewHtml}
      `;
      
      downloadBtn.style.display = 'inline-block';
      
      // Show full preview button for supported file types
      const fullPreviewBtn = document.getElementById('fullPreviewBtn');
      if (selectedItem.contentType && 
          (selectedItem.contentType.startsWith('image/') || 
           selectedItem.contentType === 'application/pdf' ||
           selectedItem.contentType.startsWith('text/'))) {
        fullPreviewBtn.style.display = 'inline-block';
      } else {
        fullPreviewBtn.style.display = 'none';
      }
      
      fileDetails.innerHTML = `
        <strong>Filename:</strong> ${filename}<br>
        <strong>Content-Type:</strong> ${selectedItem.contentType || 'Unknown'}<br>
        <strong>Content-Disposition:</strong> ${contentDisposition || 'None'}
      `;
    } catch (err) {
      console.error('Error processing file:', err);
      showAlert(`Error processing file: ${err.message}`);
      return;
    }
  }
  
  document.getElementById('itemsList').style.display = 'none';
  document.getElementById('selectedItemContent').style.display = 'block';
}

async function generateFilePreview(blob, filename, contentType) {
  const fileExt = filename.split('.').pop().toLowerCase();
  const blobUrl = URL.createObjectURL(blob);
  
  // Image files
  if (contentType && contentType.startsWith('image/')) {
    return `
      <div style="text-align: center; margin: 20px 0;">
        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; border: 2px dashed #dee2e6;">
          <div style="font-size: 1.2em; margin-bottom: 10px; color: #666;">🖼️ Image Preview</div>
          <img src="${blobUrl}" alt="${escapeHtml(filename)}" 
               style="max-width: 100%; max-height: 400px; border-radius: 5px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);" />
        </div>
      </div>
    `;
  }
  
  // PDF files
  if (contentType === 'application/pdf' || fileExt === 'pdf') {
    return `
      <div style="text-align: center; margin: 20px 0;">
        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; border: 2px dashed #dee2e6;">
          <div style="font-size: 1.2em; margin-bottom: 10px; color: #666;">📄 PDF Preview</div>
          <iframe src="${blobUrl}" 
                  style="width: 100%; height: 400px; border: none; border-radius: 5px;" 
                  title="PDF Preview"></iframe>
        </div>
      </div>
    `;
  }
  
  // Audio files
  if (contentType && contentType.startsWith('audio/')) {
    return `
      <div style="text-align: center; margin: 20px 0;">
        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; border: 2px dashed #dee2e6;">
          <div style="font-size: 1.2em; margin-bottom: 15px; color: #666;">🎵 Audio Preview</div>
          <audio controls style="width: 100%; max-width: 400px;">
            <source src="${blobUrl}" type="${contentType}">
            Your browser does not support the audio element.
          </audio>
        </div>
      </div>
    `;
  }
  
  // Video files
  if (contentType && contentType.startsWith('video/')) {
    return `
      <div style="text-align: center; margin: 20px 0;">
        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; border: 2px dashed #dee2e6;">
          <div style="font-size: 1.2em; margin-bottom: 10px; color: #666;">🎥 Video Preview</div>
          <video controls style="width: 100%; max-height: 400px; border-radius: 5px;">
            <source src="${blobUrl}" type="${contentType}">
            Your browser does not support the video element.
          </video>
        </div>
      </div>
    `;
  }
  
  // Text files (read content for preview)
  if (contentType && contentType.startsWith('text/') || 
      ['txt', 'md', 'csv', 'json', 'xml', 'html', 'css', 'js', 'py', 'java', 'cpp', 'c'].includes(fileExt)) {
    try {
      const text = await blob.text();
      const previewText = text.length > 1000 ? text.substring(0, 1000) + '\n\n... (truncated)' : text;
      return `
        <div style="margin: 20px 0;">
          <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; border: 2px dashed #dee2e6;">
            <div style="font-size: 1.2em; margin-bottom: 10px; color: #666;">📝 Text Preview</div>
            <pre style="background: white; padding: 15px; border-radius: 5px; border: 1px solid #e1e5e9; 
                       max-height: 300px; overflow-y: auto; font-size: 14px; line-height: 1.4; 
                       white-space: pre-wrap; word-wrap: break-word;">${escapeHtml(previewText)}</pre>
          </div>
        </div>
      `;
    } catch (err) {
      console.log('Could not read text content for preview:', err);
    }
  }
  
  // Office documents preview attempt
  if (['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(fileExt)) {
    return `
      <div style="text-align: center; margin: 20px 0;">
        <div style="background: #f8f9fa; padding: 30px; border-radius: 8px; border: 2px dashed #dee2e6;">
          <div style="font-size: 4em; margin-bottom: 15px;">📊</div>
          <div style="font-size: 1.2em; margin-bottom: 10px; color: #666;">Office Document</div>
          <p style="color: #666; margin-bottom: 15px;">Preview not available for this file type.</p>
          <p style="font-size: 14px; color: #888;">Download the file to view its contents.</p>
        </div>
      </div>
    `;
  }
  
  // Archive files
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(fileExt)) {
    return `
      <div style="text-align: center; margin: 20px 0;">
        <div style="background: #f8f9fa; padding: 30px; border-radius: 8px; border: 2px dashed #dee2e6;">
          <div style="font-size: 4em; margin-bottom: 15px;">📦</div>
          <div style="font-size: 1.2em; margin-bottom: 10px; color: #666;">Archive File</div>
          <p style="color: #666; margin-bottom: 15px;">Contains compressed files and folders.</p>
          <p style="font-size: 14px; color: #888;">Download to extract and view contents.</p>
        </div>
      </div>
    `;
  }
  
  // Default preview for unknown file types
  const fileIcon = getFileIcon(filename);
  return `
    <div style="text-align: center; margin: 20px 0;">
      <div style="background: #f8f9fa; padding: 30px; border-radius: 8px; border: 2px dashed #dee2e6;">
        <div style="font-size: 4em; margin-bottom: 15px;">${fileIcon}</div>
        <div style="font-size: 1.2em; margin-bottom: 10px; color: #666;">File Preview</div>
        <p style="color: #666; margin-bottom: 15px;">Preview not available for this file type.</p>
        <p style="font-size: 14px; color: #888;">Click download to save this file to your device.</p>
      </div>
    </div>
  `;
}

function getFileIcon(filename) {
  const ext = filename.split('.').pop().toLowerCase();
  const iconMap = {
    'pdf': '📄',
    'doc': '📝', 'docx': '📝',
    'xls': '📊', 'xlsx': '📊',
    'ppt': '📊', 'pptx': '📊',
    'jpg': '🖼️', 'jpeg': '🖼️', 'png': '🖼️', 'gif': '🖼️',
    'mp4': '🎥', 'avi': '🎥', 'mov': '🎥',
    'mp3': '🎵', 'wav': '🎵', 'flac': '🎵',
    'zip': '📦', 'rar': '📦', '7z': '📦',
    'txt': '📄', 'md': '📄'
  };
  return iconMap[ext] || '📄';
}

function downloadCurrentItem() {
  if (selectedItem) {
    try {
      const url = window.URL.createObjectURL(selectedItem.blob);
      const a = document.createElement('a');
      a.href = url;
      
      // Use the stored filename
      a.download = selectedItem.filename || 'downloaded_file';
      
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      showAlert("File downloaded successfully!", 'success');
    } catch (err) {
      console.error('Download error:', err);
      showAlert(`Download failed: ${err.message}`);
    }
  } else {
    showAlert("No file selected for download.");
  }
}

// New function to download text content as a file
function downloadTextAsFile() {
  if (currentTextContent) {
    try {
      // Create a blob with the text content
      const blob = new Blob([currentTextContent], { type: 'text/plain;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      // Generate filename with current date/time
      const now = new Date();
      const timestamp = now.toISOString().replace(/[:.]/g, '-').slice(0, -5);
      a.download = `text_content_${timestamp}.txt`;
      
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      showAlert("Text file downloaded successfully!", 'success');
    } catch (err) {
      console.error('Text download error:', err);
      showAlert(`Download failed: ${err.message}`);
    }
  } else {
    showAlert("No text content available for download.");
  }
}

// New function to copy text content to clipboard
async function copyToClipboard() {
  if (currentTextContent) {
    try {
      await navigator.clipboard.writeText(currentTextContent);
      showAlert("Text copied to clipboard!", 'success');
    } catch (err) {
      console.error('Copy error:', err);
      // Fallback method for older browsers
      try {
        const textArea = document.createElement('textarea');
        textArea.value = currentTextContent;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showAlert("Text copied to clipboard!", 'success');
      } catch (fallbackErr) {
        console.error('Fallback copy error:', fallbackErr);
        showAlert("Failed to copy text to clipboard. Please select and copy manually.");
      }
    }
  } else {
    showAlert("No text content available to copy.");
  }
}

function clearSelection() {
  document.getElementById('selectedItemContent').style.display = 'none';
  document.getElementById('itemsList').style.display = 'block';
  selectedItem = null;
  currentTextContent = null; // Clear stored text content
  
  // Clean up any blob URLs to prevent memory leaks
  const images = document.querySelectorAll('#contentDisplay img');
  const iframes = document.querySelectorAll('#contentDisplay iframe');
  const videos = document.querySelectorAll('#contentDisplay video');
  const audios = document.querySelectorAll('#contentDisplay audio');
  
  [...images, ...iframes, ...videos, ...audios].forEach(element => {
    if (element.src && element.src.startsWith('blob:')) {
      URL.revokeObjectURL(element.src);
    }
  });
}

function openFullPreview() {
  if (currentTextContent) {
    // Handle text content in full preview
    const newWindow = window.open();
    newWindow.document.write(`
      <html>
        <head>
          <title>Text Content - Full Preview</title>
          <style>
            body { 
              margin: 0; 
              padding: 20px; 
              background: #f5f5f5; 
              font-family: 'Consolas', 'Monaco', 'Courier New', monospace; 
              line-height: 1.6;
            }
            .header { 
              margin-bottom: 20px; 
              text-align: center; 
              padding-bottom: 15px;
              border-bottom: 2px solid #ddd;
            }
            .title { 
              font-size: 18px; 
              font-weight: bold; 
              color: #333; 
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            .stats {
              font-size: 14px;
              color: #666;
              margin-top: 5px;
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            .content { 
              background: white; 
              padding: 20px; 
              border-radius: 8px; 
              box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
              white-space: pre-wrap; 
              word-wrap: break-word;
              font-size: 14px;
              border: 1px solid #ddd;
            }
            .toolbar {
              position: fixed;
              top: 10px;
              right: 10px;
              background: rgba(255,255,255,0.9);
              padding: 10px;
              border-radius: 5px;
              box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .toolbar button {
              margin: 0 5px;
              padding: 5px 10px;
              border: none;
              border-radius: 3px;
              background: #667eea;
              color: white;
              cursor: pointer;
              font-size: 12px;
            }
            .toolbar button:hover {
              background: #5a6fd8;
            }
          </style>
        </head>
        <body>
          <div class="toolbar">
            <button onclick="window.print()">🖨️ Print</button>
            <button onclick="document.execCommand('selectAll')">📋 Select All</button>
          </div>
          <div class="header">
            <div class="title">📝 Text Content - Full Preview</div>
            <div class="stats">
              ${currentTextContent.split('\n').length} lines • 
              ${currentTextContent.split(/\s+/).filter(w => w.length > 0).length} words • 
              ${currentTextContent.length} characters
            </div>
          </div>
          <div class="content">${currentTextContent.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
        </body>
      </html>
    `);
    newWindow.document.close();
  } else if (selectedItem && selectedItem.blob) {
    // Handle file content in full preview
    const blobUrl = URL.createObjectURL(selectedItem.blob);
    const newWindow = window.open();
    
    if (selectedItem.contentType && selectedItem.contentType.startsWith('image/')) {
      newWindow.document.write(`
        <html>
          <head>
            <title>${selectedItem.filename}</title>
            <style>
              body { margin: 0; padding: 20px; background: #f5f5f5; text-align: center; font-family: Arial, sans-serif; }
              img { max-width: 100%; max-height: 90vh; border-radius: 8px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
              .header { margin-bottom: 20px; }
              .filename { font-size: 18px; font-weight: bold; color: #333; }
            </style>
          </head>
          <body>
            <div class="header">
              <div class="filename">${selectedItem.filename}</div>
            </div>
            <img src="${blobUrl}" alt="${selectedItem.filename}" />
          </body>
        </html>
      `);
    } else if (selectedItem.contentType === 'application/pdf') {
      newWindow.location.href = blobUrl;
    } else if (selectedItem.contentType && selectedItem.contentType.startsWith('text/')) {
      selectedItem.blob.text().then(text => {
        newWindow.document.write(`
          <html>
            <head>
              <title>${selectedItem.filename}</title>
              <style>
                body { margin: 0; padding: 20px; background: #f5f5f5; font-family: monospace; }
                .header { margin-bottom: 20px; text-align: center; }
                .filename { font-size: 18px; font-weight: bold; color: #333; }
                .content { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); white-space: pre-wrap; }
              </style>
            </head>
            <body>
              <div class="header">
                <div class="filename">${selectedItem.filename}</div>
              </div>
              <div class="content">${text.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
            </body>
          </html>
        `);
      });
    }
    
    newWindow.document.close();
  }
}

// Generate a random unique PIN
async function generateRandomPin() {
  const generateBtn = event.target;
  const originalText = generateBtn.innerHTML;
  generateBtn.innerHTML = '🔄 Checking...';
  generateBtn.disabled = true;
  
  try {
    let attempts = 0;
    const maxAttempts = 10;
    
    while (attempts < maxAttempts) {
      // Generate a random 6-digit PIN
      const randomPin = Math.floor(100000 + Math.random() * 900000).toString();
      
      // Check if this PIN is unique
      const isUnique = await checkPinUniqueness(randomPin);
      
      if (isUnique) {
        document.getElementById('pin').value = randomPin;
        showAlert(`Generated unique PIN: ${randomPin}`, 'success');
        break;
      }
      
      attempts++;
    }
    
    if (attempts >= maxAttempts) {
      showAlert("Could not generate a unique PIN after several attempts. Please try manually entering a PIN.");
    }
  } catch (err) {
    console.error('Error generating PIN:', err);
    showAlert("Error generating PIN. Please try manually entering a PIN.");
  } finally {
    generateBtn.innerHTML = originalText;
    generateBtn.disabled = false;
  }
}

// Test backend connection
async function testConnection() {
  try {
    console.log('Testing connection to:', API_BASE);
    const response = await fetch(`${API_BASE}/store-text`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        title: "connection-test", 
        pin: "1234", 
        content: "test content" 
      })
    });
    
    console.log('Response status:', response.status);
    const responseText = await response.text();
    console.log('Response body:', responseText);
    
    if (response.ok) {
      showAlert('Backend connection successful!', 'success');
    } else {
      showAlert(`Backend responded with error: ${response.status} - ${responseText}`);
    }
  } catch (err) {
    console.error('Connection test failed:', err);
    showAlert(`Connection test failed: ${err.message}`);
  }
}

// Utility: Escape HTML
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}